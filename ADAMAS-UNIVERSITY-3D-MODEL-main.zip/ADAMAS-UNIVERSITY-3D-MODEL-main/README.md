au12.mb is a maya model for AU1 only.
AU1 is a college infrastructure outside.
